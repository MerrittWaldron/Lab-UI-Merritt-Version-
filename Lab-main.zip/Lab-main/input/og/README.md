Download the Ekos report titled BAX OG by Batch and drop it here. 
