
Download a CSV of the Ekos report titled BAX Conditioning Log and place it in this folder. 
