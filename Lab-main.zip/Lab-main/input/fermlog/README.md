
Download a CSV of the Ekos report titled BAX Ferm Log and place it in this folder. 
