
Download a CSV of the Ekos report titled BAX Malts and place it in this folder. 
