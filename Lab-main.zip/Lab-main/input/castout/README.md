
Download a CSV file from the Ekos report titled BAX Castout and place it in this folder.
